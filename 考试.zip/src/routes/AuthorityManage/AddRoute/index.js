import React from 'react'
import AddRouter from './AddRouter'

class AddRoute extends React.Component{
    render(){
        return(
            <div style={{background:'#fff',borderRadius:'5px'}}>
                <AddRouter></AddRouter>
            </div>
        )
    }
}
export default AddRoute