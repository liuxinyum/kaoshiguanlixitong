import React from 'react'

class RoleAuthority extends React.Component{
    render(){
        return(
            <div>
                角色权限
            </div>
        )
    }
}
export default RoleAuthority