import React from 'react'
import Classify from './Classify/Classify.js'

class questionsClassify extends React.Component {
	render() {
		return (
			<React.Fragment>
				<Classify></Classify>
			</React.Fragment>
		)
	}
}

export default questionsClassify