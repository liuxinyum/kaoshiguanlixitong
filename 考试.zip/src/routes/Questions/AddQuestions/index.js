import React from 'react'
import TestQuestions from '@/components/TestQuestions/index'

class AddQuestions extends React.Component{
	render(){
		return <TestQuestions typewithquestions="add"></TestQuestions>
	}
}
export default AddQuestions