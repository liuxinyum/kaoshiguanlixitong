
export default {
	namespace: 'AuthorityManage',
	state: {
        
	},
	reducers: {
		
	},
	effects: {

	}
}